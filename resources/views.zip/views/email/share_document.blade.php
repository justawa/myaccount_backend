@component('mail::message')
# Document Shared

A document has been shared with you!

Thanks,<br>
{{ config('app.name') }}
@endcomponent