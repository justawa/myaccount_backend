<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaleOrderSetting extends Model
{
    protected $table = 'user_sale_order_settings';

    protected $guarded = [];
}
