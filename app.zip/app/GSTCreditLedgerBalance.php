<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTCreditLedgerBalance extends Model
{
    protected $table = 'credit_ledger_balance';
}
