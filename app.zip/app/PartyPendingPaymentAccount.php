<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PartyPendingPaymentAccount extends Model
{
    protected $table = 'party_pending_payment_account';
}
