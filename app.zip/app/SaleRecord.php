<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaleRecord extends Model
{
    //
}
