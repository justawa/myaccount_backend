<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CashGST extends Model
{
    protected $table = 'cash_gst';
}
