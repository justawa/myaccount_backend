<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GstList extends Model
{
    protected $table = 'gstlists';
}
