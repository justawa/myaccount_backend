<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoteSetting extends Model
{
    protected $table = 'user_note_settings';

    protected $guarded = [];
}
