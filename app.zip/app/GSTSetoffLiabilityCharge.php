<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTSetoffLiabilityCharge extends Model
{
    protected $table = 'gst_setoff_liability_charges';
}
