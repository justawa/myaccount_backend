<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTCashLedgerBalance extends Model
{
    protected $table = 'cash_ledger_balance';
}
