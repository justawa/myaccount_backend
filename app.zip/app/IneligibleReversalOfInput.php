<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IneligibleReversalOfInput extends Model
{
    //
}
