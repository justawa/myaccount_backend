<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CashWithdrawDocument extends Model
{
    protected $table = 'uploaded_cash_withdraw_documents';
}
