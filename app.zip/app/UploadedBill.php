<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UploadedBill extends Model
{
    //
}
