<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTSetOff extends Model
{
    protected $table = 'gst_set_off';
}
