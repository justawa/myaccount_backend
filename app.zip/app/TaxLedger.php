<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaxLedger extends Model
{
    //
}
