<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CashDepositDocument extends Model
{
    protected $table = 'uploaded_cash_deposit_documents';
}
