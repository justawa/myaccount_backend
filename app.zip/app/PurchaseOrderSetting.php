<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrderSetting extends Model
{
    protected $table = 'user_purchase_order_settings';

    protected $guarded = [];
}
