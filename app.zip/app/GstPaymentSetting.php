<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GstPaymentSetting extends Model
{
    protected $table = 'user_gst_payment_settings';

    protected $guarded = [];
}
