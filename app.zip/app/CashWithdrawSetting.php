<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CashWithdrawSetting extends Model
{
    protected $table = 'user_cash_withdraw_settings';

    protected $guarded = [];
}
