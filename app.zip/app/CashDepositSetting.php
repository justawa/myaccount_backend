<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CashDepositSetting extends Model
{
    protected $table = 'user_cash_deposit_settings';

    protected $guarded = [];
}
