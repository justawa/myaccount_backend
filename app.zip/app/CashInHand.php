<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CashInHand extends Model
{
    protected $table = 'cash_in_hand';

    public $timestamps = false;
}
