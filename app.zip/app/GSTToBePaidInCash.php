<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTToBePaidInCash extends Model
{
    protected $table = 'gst_to_be_paid_in_cash';
}
