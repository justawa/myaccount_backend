<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTSetoffReverseCharge extends Model
{
    protected $table = 'gst_setoff_reverse_charges';
}
