<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UploadBankStatement extends Model
{
    protected $guarded = [];
}
