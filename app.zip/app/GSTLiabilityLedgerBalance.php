<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTLiabilityLedgerBalance extends Model
{
    protected $table = 'liability_ledger_balance';
}
