<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTSetoffOtherThanReverseCharge extends Model
{
    protected $table = 'gst_setoff_other_than_reverse_charges';
}
