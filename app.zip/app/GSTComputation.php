<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GSTComputation extends Model
{
    protected $table = 'gst_computations';
}
