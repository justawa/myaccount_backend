<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseSetting extends Model
{
    protected $table = 'user_purchase_settings';

    protected $guarded = [];
}
