<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SelectOption extends Model
{
    protected $table = 'select_option';

    protected $guarded = [];
}
