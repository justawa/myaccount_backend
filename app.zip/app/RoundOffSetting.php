<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoundOffSetting extends Model
{
    protected $guarded = [];
}
